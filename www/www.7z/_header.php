        <div style="background-color: white">

            <center><img src="http://www.qu.edu.sa/logo/1518469571_3475_5259.png" alt="Qassim University Logo" </center>

        </div>
