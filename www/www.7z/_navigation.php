            <div class="space">
                <center>
                <a href="index.php">Sending a request</a>
                |
                <a href="doctor.php">Session Control</a>
                |
                <a href="manager.php">Session Creation</a> </center>
            </div>
